Hi there!

Please note that this repository is under construction. Development is publicly visible, but no releases are provided. The wiki is largely complete.

For a more user-friendly experience, please see [here](https://www.nexusmods.com/battlebrothers/mods/643). Thank you for your interest!
